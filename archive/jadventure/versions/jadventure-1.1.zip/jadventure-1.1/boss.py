"""
Boss fight and all its dependencies
"""

import time
import random
import sys

import variables
import death

npc_dead = False

def npc_help():
    bready = False
    variables.boss_name = random.choice(variables.boss_mons)
    print("""
A man appears from the trees, a man clad in steel. Another foe? \"Salutations
my friend. I am %s of al'Baham, Knight of the Cross and Warden of
Bak'al-Thur. I see you also seek to destroy %s. Let me be
of assistance to you.\"
""" % (variables.npc_name, variables.boss_name))
    while bready == False:
        try:
            print("Listen to him?")
            npc_listen = input("> ")

            if npc_listen == 'y' or npc_listen == 'yes':
                print("""
\"Very well, %s. With me I have brought a legendary artifact from
Katobr, the dragonslayer spear used by Melbrith during the Dark Wars. It is to
be given only to the most able, and you have survived ten journeys into the
Blasted Lands. This I gift to thee.\"
""" % variables.role)
                variables.inventory = 4
                time.sleep(5)
                if variables.hp != 20:
                    variables.hp = 20
                    print("\"You are wounded. Hold on...\"")
                    time.sleep(2)
                    print("%s casts a spell!" % variables.npc_name)
                    time.sleep(1)
                    print("You are surrounded by a light blue aura.")
                    print()
                    time.sleep(1)

                print("\"Let us make haste, then. %s will be in his cave.\""
                        % variables.boss_name)
                print()

                while True:
                    try:
                        print("Enter 'ready' to proceed.")
                        bossready = input("> ")

                        if bossready == 'ready':
                            bready = True
                            bossoptions()
                            break

                    except KeyboardInterrupt:
                        print()
                        pass

                    except EOFError:
                        print()
                        print("Not staying? That's too bad. See you soon!")
                        sys.exit()

            elif npc_listen == 'n' or npc_listen == 'no':
                # hint that maybe the NPC isn't so nice after all...
                print(""""
\"So be it then.\" Without even a glance, %s raised a hand, and at his
signal a storm of arrows fell down on you. Now that's just unfair!
    """ % variables.npc_name)
                time.sleep(1)
                death.death()
                break

            else:
                print("Please enter 'yes' or 'no'.")

        except KeyboardInterrupt:
            print()
            pass

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()

def bossoptions():
    print("""
A monstrous creature slithers out of the cave, its scales glistening in the
black sun. A serpent, no a lizard, no... a dragon. You ready your spear and
prepare for battle. This is %s himself. The great dragon.

This will be his end."""
% variables.boss_name)
    time.sleep(4)
    while True:
        try:
            print("""
You may choose from the following options:
[a] - Attack
[b] - Trickery
[c] - Dance
[d] - Run""")
            bo_choice = input("> ")

            if bo_choice == "a":
                bossfight()
                break

            elif bo_choice == "b":
                print("\"You can't fool %s!\" %s shouts."
                        % (variables.boss_name, variables.npc_name))

            elif bo_choice == "c":
                print("\"No, how could this be?\" cries %s. \"No. No! NOOOOO!\""
                        % variables.boss_name)
                time.sleep(4)

                print("""
Your dance becomes more vibrant, and you jump gracefully as
%s screams in pain. %s's mouth drops open.
\"This was his weakness?\"
""" % (variables.boss_name, variables.npc_name))
                time.sleep(4)

                print("""%s's scales begin to blister, and pus flows out of his
once paralyzing eyes. Your feet move like a tornado, arms moving with
dexterous calm. With a final throat wrenching scream, %s
collapses. %s plunges his sword into the beast."""
% (variables.boss_name, variables.boss_name, variables.npc_name))
                time.sleep(6)
                victory()
                break

            elif bo_choice == "d":
                print("""Brave Sir %s ran away,
Bravely ran away away.

When danger reared its ugly head,
He bravely turned his tail and fled.

Yes, brave Sir %s turned about,
And gallantly he chickened out.

Bravely taking to his feet,
He beat a very brave retreat.
""" % (variables.name, variables.name))
                time.sleep(4)
                print("Bravest of the brave, Sir %s!" % variables.name)
                print()
                death.run()
                break

            else:
                print("Please choose from the following options.")

        except KeyboardInterrupt:
            print()
            pass

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()

def bossfight():
    global npc_dead

    npc_dead = False

    # NPC stats
    npc_hp = 20
    npc_damage = random.randint(4, 16)
    npc_heal = random.randint(2, 10) # area heal

    # boss stats
    boss_hp = 220
    boss_damage = random.randint(9, 19)
    boss_breath = random.randint(4, 11) # area damage

    while True:
        dragonspearhit = random.choice(variables.dragonspearflav)
        npchit = random.choice(variables.npcflav)
        bosshit = random.choice(variables.bossflav)

        # here in case I decide in the future to add more weapons
        if variables.inventory == 4:
            pldamage = random.randint(7, 12)

        pl_hitchance = random.randint(1, 5)
        npc_hitchance = random.randint(1, 7)
        boss_hitchance = random.randint(1, 4)

        # player hits first
        if pl_hitchance == 1:
            print("Your swing wildly misses %s." % variables.boss_name)
            time.sleep(2)
        else:
            if variables.inventory == 4:
                print("You %s %s, dealing %d damage!"
                        % (dragonspearhit, variables.boss_name, pldamage))
                boss_hp = boss_hp - pldamage

                if boss_hp < 1:
                    # if this ever runs, you are ultra-lucky
                    time.sleep(1)
                    victory()
                    break
                else:
                    time.sleep(2)

        # followed by the NPC
        if npc_dead == False:
            if npc_hitchance == 1:
                print("%s's swing misses %s!"
                        % (variables.npc_name, variables.boss_name))
                time.sleep(2)
            
            elif npc_hitchance > 5:
                print("%s casts a spell!" % variables.npc_name)
                time.sleep(1)
                print("%s is surrounded by a light blue aura."
                        % variables.npc_name)
                print("You are surrounded by a light blue aura.")

                if (variables.hp + npc_heal) > variables.maxhp:
                    variables.hp = variables.maxhp
                else:
                    variables.hp = variables.hp + npc_heal

                if (npc_hp + npc_heal) > variables.maxhp:
                    npc_hp = variables.maxhp
                else:
                    npc_hp = npc_hp + npc_heal
                time.sleep(2)

            else:
                print("%s %s %s, dealing %d damage!"
                        % (variables.npc_name, npchit, variables.boss_name,
                            npc_damage))
                boss_hp = boss_hp - npc_damage

                if boss_hp < 1:
                    # if this ever runs, you are ultra-lucky
                    time.sleep(1)
                    victory()
                    break
                else:
                    time.sleep(2)
        else:
            pass

        # and finally the boss
        if boss_hitchance == 1:
            print("%s snaps wildly." % variables.boss_name)
            time.sleep(2)

        elif boss_hitchance == 2:
            print("%s breathes fire, causing %d area damage!"
                    % (variables.boss_name, boss_breath))
            variables.hp = variables.hp - boss_breath
            npc_hp = npc_hp - boss_breath

            if variables.hp < 1:
                time.sleep(1)
                death.death()
                break
            elif npc_hp < 1 and npc_dead == False:
                npc_death()
            else:
                time.sleep(2)

        else:
            hitchoice = random.randint(1, 2)
            if hitchoice == 1:
                print("%s %s you, dealing %d damage!"
                        % (variables.boss_name, bosshit, boss_damage))
                variables.hp = variables.hp - boss_damage

                if variables.hp < 1:
                    death.death()
                    break
                else:
                    time.sleep(2)

            elif hitchoice == 2:
                if npc_dead == False:
                    print("%s %s %s, dealing %d damage!"
                            % (variables.boss_name, bosshit, variables.npc_name,
                                boss_damage))
                    npc_hp = npc_hp - boss_damage

                    if npc_hp < 1 and npc_dead == False:
                        npc_death()
                    else:
                        time.sleep(2)
                else:
                    print("%s %s you, dealing %d damage!"
                            % (variables.boss_name, bosshit, boss_damage))
                    variables.hp = variables.hp - boss_damage

                    if variables.hp < 1:
                        death.death()
                        break
                    else:
                        time.sleep(2)

def npc_death():
    global npc_dead
    time.sleep(1)
    print("""
\"Far from home I fall, but in vain 'tis not! Avenge me!\"
And with that, %s collapses in a pool of blood.
""" % variables.npc_name)
    npc_dead = True
    time.sleep(4)

def victory():
    print("""
%s slumps to the ground, eyes blazing. "This is not the
end!" %s sputters, tail thrashing angrily. %s
steps back from the beast, blood-covered sword lowered. "It is done," he says.
"%s will trouble nor man nor creature any further."
And with that, %s collapses, dying in his own blood.
""" % (variables.boss_name, variables.boss_name, variables.npc_name,
    variables.boss_name, variables.boss_name))

    variables.boss_death = True
    time.sleep(6)

    print("""Congratulations! You have reached the end of JAdventure.
Would you like to continue playing, retire, or replay the boss fight?""")

    while True:
        try:
            continue_choice = input("> ")
            if continue_choice == 'continue':
                variables.continueplay = True
                break
            elif continue_choice == 'retire':
                death.retire()
                break
            elif continue_choice == 'replay':
                death.replayboss()
                break
            else:
                print("Please enter 'continue', 'retire', or 'replay'.")

        except KeyboardInterrupt:
            print()
            pass

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()
