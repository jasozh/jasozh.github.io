"""
Main program
"""

import time
import random
import sys

import variables
import beginning
import valleys
import boss

def status_bar():
    inv_stat = ""
    wis_stat = ""

    if variables.inventory == 0:
        inv_stat = "None"
    elif variables.inventory == 1:
        inv_stat = "Club"
    elif variables.inventory == 2:
        inv_stat = "Sword"
    elif variables.inventory == 3:
        inv_stat = "Crossbow"
    elif variables.inventory == 4:
        inv_stat = "Dragonslayer Spear"

    if variables.wisdom == 0:
        wis_stat = "Low"
    elif variables.wisdom == 1:
        wis_stat = "Medium"
    elif variables.wisdom == 2:
        wis_stat = "High"
    elif variables.wisdom > 2:
        wis_stat = "Very High"

    print("Hitpoints: %d(%d) \t Inventory: %s \t Wisdom: %s"
            % (variables.hp, variables.maxhp, inv_stat, wis_stat))

def main():
    try:
        if variables.survive_num == 10 and variables.continueplay == False:
            print("""
Ahead of you is a single narrow path made up of red gravel. Bordering it is
a thick line of trees, but scraggly trees who are but mere skeletons of what
they once were. A dry gust strongly blows westward, and a black sun (a black
sun?) stands in the red sky, blacker than black yet more blinding than a star.

***NOTE: YOU WILL RESPAWN HERE***""")
            status_bar()
            print()

            while True:
                print("Enter 'ready' to proceed.")
                ready = input("> ")

                if ready == 'ready':
                    boss.npc_help()
                    break
        else:
            print()
            print("You have come across two paths. Take which one? (1 or 2)")
            status_bar()

            pathluck = random.randint(1, 2)
            pathchoice = input("> ")

            if pathchoice == "1" or pathchoice == "2":
                pathchoice = int(pathchoice)

                if pathchoice == pathluck:
                    print("You walk along the dirt path...")
                    time.sleep(2)
                    valleys.happy()
                else:
                    print("You walk along the dirt path...")
                    time.sleep(2)
                    valleys.doom()
            else:
                print("Please enter '1' or '2'.")

    except KeyboardInterrupt:
        print()
        pass

    except EOFError:
        print()
        print("Not staying? That's too bad. See you soon!")
        sys.exit()

beginning.welcome()
while True:
    main()
