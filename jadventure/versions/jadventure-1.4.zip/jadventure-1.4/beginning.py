"""
Covers everything before main()
Includes welcome messges and choosing roles
"""

import sys

import variables

def welcome():
    while True:
        try:
            print("What is your name?")
            variables.name = input("> ")

            if len(variables.name) > 9:
                print("Your name must be below 10 characters.")
                print()

            elif len(variables.name) == 0:
                pass
            else:
                break
        
        except KeyboardInterrupt:
            print()

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()

    choosing_roles()
    print("Welcome to JAdventure, %s the %s!"
            % (variables.name, variables.role))

def choosing_roles():
    while True:
        try:
            print("""Choose your role:
[a] - Arbalist
[b] - Bandit
[k] - Knight
[s] - Sage
[t] - Tourist""")

            if variables.cheat_help > 9:
                print("[v] - Vicar of Katobr (Cheat Help)")

            role_choice = input("> ")

            if role_choice == "a":
                variables.inventory = 3
                variables.role = "Arbalist"
                break
            elif role_choice == "b":
                variables.inventory = 1
                variables.role = "Bandit"
                break
            elif role_choice == "k":
                variables.inventory = 2
                variables.role = "Knight"
                break
            elif role_choice == "s":
                variables.wisdom = 2
                variables.role = "Sage"
                break
            elif role_choice == "t":
                variables.wisdom = 1
                variables.role = "Tourist"
                break

            elif variables.cheat_help > 9 and role_choice == "v":
                variables.wisdom = 3
                variables.inventory = 3
                variables.role = "Vicar of Katobr"
                break

            else:
                print("Please choose from the following options.")
                print()

        except KeyboardInterrupt:
            print()

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()

def status_bar():
    inv_stat = ""
    wis_stat = ""

    if variables.inventory == 0:
        inv_stat = "None"
    elif variables.inventory == 1:
        inv_stat = "Club"
    elif variables.inventory == 2:
        inv_stat = "Sword"
    elif variables.inventory == 3:
        inv_stat = "Crossbow"
    elif variables.inventory == 4:
        inv_stat = "Dragonslayer Spear"

    if variables.wisdom == 0:
        wis_stat = "Low"
    elif variables.wisdom == 1:
        wis_stat = "Medium"
    elif variables.wisdom == 2:
        wis_stat = "High"
    elif variables.wisdom > 2:
        wis_stat = "Very High"

    print("Inventory: %s \t\t Wisdom: %s"
            % (inv_stat, wis_stat))
