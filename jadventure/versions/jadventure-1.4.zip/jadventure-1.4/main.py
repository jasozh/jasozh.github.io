"""
Main program
"""

import time
import random
import sys

import variables
import mapgen
import beginning
import valleys
import boss

def main():
    try:
        if variables.survive_num == 10 and variables.continueplay == False:
            if variables.boss_visited == False:
                print("""
Ahead of you is a single narrow path made up of red gravel. Bordering it is
a thick line of trees, but scraggly trees who are but mere skeletons of what
they once were. A dry gust strongly blows westward, and a black sun (a black
sun?) stands in the red sky, blacker than black yet more blinding than a star.

***NOTE: YOU WILL RESPAWN HERE***""")

            else:
                print("Ahead of you is a narrow path made up of red gravel.")

            status_bar()
            print()

            while True:
                print("Enter 'ready' to proceed.")
                ready = input("HP: %s(%s)> " % (variables.hp, variables.maxhp))

                if ready == 'ready':
                    boss.npc_help()
                    break
        else:
            '''
            print()
            print("You have come across two paths. Take which one? (1 or 2)")
            status_bar()

            pathluck = random.randint(1, 2)
            pathchoice = input("HP: %s(%s)> " % (variables.hp, variables.maxhp))

            if pathchoice == "1" or pathchoice == "2":
                pathchoice = int(pathchoice)

                if pathchoice == pathluck:
                    valleys.happy()
                else:
                    valleys.doom()
            else:
                print("Please enter '1' or '2'.")
            '''
            mapgen.callmaps()
            pathluck = random.randint(1, 2)
            if pathluck == 1:
                valleys.doom()
            elif pathluck == 2:
                valleys.happy()

    except KeyboardInterrupt:
        print()
        pass

    except EOFError:
        print()
        print("Not staying? That's too bad. See you soon!")
        sys.exit()

print("""JAdventure: A Tale of Two Valleys
Copyright (c) Jason Zheng 2016
Version 1.4.0
""")

beginning.welcome()
mapgen.mapgen()
while True:
    main()
