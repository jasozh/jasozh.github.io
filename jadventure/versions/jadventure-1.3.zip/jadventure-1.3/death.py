"""
What happens if player dies
"""

import time
import sys

import beginning
import variables

def death():
    print("You die...")
    time.sleep(1)
    stats()

def retire():
    print("You retire to a happy sunny farmhouse in Lenniqun...")
    variables.survive_num = 0
    time.sleep(1)
    stats()

def run():
    print("Disgraced by all, you ran away, away, away...")
    time.sleep(1)
    stats()

def replayboss():
    variables.hp = 20
    variables.inventory = 0
    variables.boss_death = False
    pass

def stats():
    if variables.boss_death == True:
        points = (9 * variables.survive_num) + (4 * variables.killcount) + 250
    else:
        points = (9 * variables.survive_num) + (4 * variables.killcount)

    if variables.boss_death == True:
        print("""
Farewell %s the %s! You have survived %d trip(s) into the Valley of
Doom, killed %d monster(s), and defeated %s.
You have accumulated %d points.
""" % (variables.name, variables.role, variables.survive_num,
    variables.killcount, variables.boss_name, points))

    else:
        print("""
Farewell %s the %s! You have survived %d trip(s) into the Valley
of Doom and killed %d monster(s). You have accumulated %d points.
""" % (variables.name, variables.role, variables.survive_num,
    variables.killcount, points))
    
    while True:
        try:
            if variables.survive_num == 10:
                print("Would you like to respawn?")
            else:
                print("Would you like to play again?")
            playagain = input("> ")

            if playagain == 'y' or playagain == 'yes':
                if variables.survive_num == 10:
                    variables.hp = 20
                    variables.inventory = 0
                    break
                else:
                    variables.hp = 20
                    variables.wisdom = 0
                    variables.inventory = 0
                    variables.survive_num = 0
                    variables.killcount = 0
                    variables.cheat_help = variables.cheat_help + 1
                    beginning.welcome()
                    break
            elif playagain == 'n' or playagain == 'no':
                print("That's too bad. See you soon!")
                sys.exit()
            else:
                print("Please enter 'yes' or 'no'.")
                print()

        except KeyboardInterrupt:
            print()

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()
