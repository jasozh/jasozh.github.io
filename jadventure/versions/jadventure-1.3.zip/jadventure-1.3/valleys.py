"""
Code for entering the Valley of Doom and the Valley of Happiness
"""

import time
import random
import sys

import variables
import combat
import death

# placeholder variables in order to work-around the local variable problem
flyenemy = ""
trickenemy = ""
weakenemy = ""

trickchance = 0

def item_pickup():
    print("You found a %s!"
            % variables.inv_names[variables.itemfound - 1])
    if variables.inventory == 0:
        variables.inventory = variables.itemfound
    else:
        while True:
            try:
                print()
                print("Exchange your %s for the %s?" %
                        (variables.inv_names[variables.inventory - 1],
                            variables.inv_names[variables.itemfound - 1]))
                take_choice = input("HP: %s(%s)>"
                        % (variables.hp, variables.maxhp))
                if take_choice == 'y' or take_choice == 'yes':
                    print("You discard your previous item.")
                    variables.inventory = variables.itemfound
                    break
                elif take_choice == 'n' or take_choice == 'no':
                    print("You ignore the %s."
                            % variables.inv_names[variables.itemfound - 1])
                    break
                else:
                    print("Please enter 'yes' or 'no'.")

            except KeyboardInterrupt:
                print()

            except EOFError:
                print()
                print("Not staying? That's too bad. See you soon!")
                sys.exit()

def happy():
    if variables.happy_visited == False:
        print("""
You find yourself in a lush, green valley full of life. A gurgling stream lies
nearby, and the aroma of freshly bloomed flowers wafts towards you. Looking at
the clear blue sky, you relax, for you have arrived at the Valley of Happiness!
""")
        variables.happy_visited = True
        variables.textbreak()
    else:
        print()
        print("You have arrived again at the Valley of Happiness!")

    goodluck = random.randint(1, 8)

    # finding items
    if goodluck == 1:
        variables.itemfound = 1
        item_pickup()
    elif goodluck == 2:
        variables.itemfound = 2
        item_pickup()
    elif goodluck == 3:
        variables.itemfound = 3
        item_pickup()
    
    # increasing wisdom
    elif goodluck == 4:
        print("You feel wise!")
        variables.wisdom = variables.wisdom + 1

    # rest of the time refills HP
    else:
        print("You are surrounded by a light blue aura.")
        variables.hp = variables.maxhp

def options():
    variables.opchoice = 1
    options_firsttime = False

    while variables.opchoice == 1:
        try:
            if options_firsttime == False:
                print("""
You may choose from the following options:
[a] - Attack
[t] - Trickery
[d] - Dance""")
                options_firsttime = True

            option_choice = input("HP: %s(%s)>"
                    % (variables.hp, variables.maxhp))

            if option_choice == "a" or option_choice == "attack":
                fight_option()

            elif option_choice == "t" or option_choice == "trick":
                global trickchance

                if variables.wisdom == 0:
                    print("The %s is not impressed by your puny magic tricks."
                            % variables.char_enemy)
                    print("The %s attempts to eat you!" % variables.char_enemy)
                    variables.textbreak()
                    retreat()
                    break

                elif variables.wisdom == 1:
                    trickchance = random.randint(1, 4)
                    trick_option()
                    break
                elif variables.wisdom == 2:
                    trickchance = random.randint(1, 3)
                    trick_option()
                    break
                elif variables.wisdom > 2:
                    trickchance = random.randint(1, 2)
                    trick_option()
                    break
                                    
            elif option_choice == "d" or option_choice == "dance":
                dance = random.choice(variables.dancename)
                print("You dance the %s!" % dance)
                print("The %s attempts to eat you!" % variables.char_enemy)
                variables.textbreak()
                retreat()
                break
            else:
                print("""
You may choose from the following options:
[a] - Attack
[t] - Trickery
[d] - Dance""")

        except KeyboardInterrupt:
            print() 

        except EOFError:
            print()
            print("Not staying? That's too bad. See you soon!")
            sys.exit()

def trick_option():
    global trickchance

    if trickchance == 1:
        print(random.choice(variables.trickflav))
        variables.survive_num = variables.survive_num + 1
    else:
        print(random.choice(variables.trickfail))
        retreat()

def fight_option():
    if variables.char_enemy == weakenemy:
        if variables.inventory == 0:
            print("You have nothing to fight the %s with!"
                    % variables.char_enemy)
            print("The %s attempts to eat you!" % variables.char_enemy)
            variables.textbreak()
            retreat()
            variables.opchoice = 0
        else:
            combat.combat()

    elif variables.char_enemy == flyenemy:
        if variables.inventory == 3 or variables.inventory == 4:
            combat.combat()
        else:
            print("Unfortunately, you cannot reach the %s."
                    % variables.char_enemy)
            print("The %s attempts to eat you!" % variables.char_enemy)
            variables.textbreak()
            retreat()
            variables.opchoice = 0

def doom():
    global weakenemy
    global trickenemy
    global flyenemy

    if variables.doom_visited == False:
        print("""
You arrive at a desolate bleak valley, one eerily quiet. Tumbleweeds blow in
the harsh gust, and skeletal remains of massive creatures lie bleached under
the eternal red sun. A thin fog covers the area, and you begin to wonder what
might hide behind. This is indeed the Valley of Doom.
""")
        variables.doom_visited = True
        variables.textbreak()
    else:
        print()
        print("You have arrived again at the Valley of Doom!")

    # monster generation
    weakgen = random.choice(variables.weak_mons)
    flygen = random.choice(variables.flying_mons)
    trickgen = random.choice(variables.tricky_mons)

    weakenemy = weakgen
    flyenemy = flygen
    trickenemy = trickgen

    enemyclass = [flyenemy, trickenemy, weakenemy]

    variables.char_enemy = random.choice(enemyclass)
    print("A %s appears out of nowhere!" % variables.char_enemy)

    if variables.char_enemy == trickenemy:
        print()
        print("What magnificent beauty! You reach out to the %s..."
                % variables.char_enemy)
        time.sleep(1)

        if variables.wisdom < 2:
            print("...and the %s bursts into flames." % variables.char_enemy)
            variables.textbreak()
            retreat()
        else:
            print("...but you notice the trap and step back.")
            variables.survive_num = variables.survive_num + 1
            time.sleep(1)
    else:
        options()

def retreat():
    rundamage = random.randint(5, 15)
    variables.hp = variables.hp - rundamage

    if variables.hp < 1:
        death.death()
    else:
        print("You barely escape the Valley of Doom, suffering %d damage."
                % rundamage)
    pass
