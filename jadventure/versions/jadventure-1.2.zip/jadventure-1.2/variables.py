"""
All global variables for reference in other modules
"""

import getpass

"""
Weak monsters needs items to kill
Flying monsters needs crossbow to kill
Tricky monsters needs wisdom to avoid
Boss monsters are... the boss
"""
weak_mons = ['goblin', 'kobold', 'pixie', 'dark elf', 'skeleton', 'newt']
flying_mons = ['bat', 'vulture', 'gryphon', 'dragon hatchling']
tricky_mons = ['chair', 'butterfly', 'striped ball', 'golden crown']
boss_mons = ['Jason the fire dragon', 'Vashik, Dragon of Baman']

# 0 = none; 1 = club; 2 = sword; 3 = crossbow; 4 = dragonslayer spear
inventory = 0
inv_names = ['club', 'sword', 'crossbow']
itemfound = 0

# 0 = low; 1 = medium; 2 = high
wisdom = 0

# all player information is here
name = ""
role = ""
hp = 20
maxhp = 20
killcount = 0
survive_num = 0
cheat_help = 0
boss_death = False

# NPC information
npc_name = "Sir Edouard"

# allow first-time description
happy_visited = False
doom_visited = False

boss_visited = False

continueplay = False

# monster the player is going to face
char_enemy = ""
boss_name = ""

# flavor texts
dancename = ['cha-cha', 'tango', 'ballet', 'Irish jig']

trickflav = ['You vanished in a puff of smoke. Now *that* was a good trick.',
        'You turned your pathetic foe into an ant. Squish.',
        'From your sleeve you pulled out a duelling pistol. Bam!',
        'You created a bunch of smoke and ran away in the confusion.']

trickfail = ['You artfully acted out your death. You forgot about vultures.',
        'You pulled a carnivorous rabbit out of your hat. You look tasty.',
        'You turned into a newt. Newts die very easily.',
        'While performing, you tripped and fell into a bottomless hole.']

clubflav = ['beat', 'smack', 'bash', 'crush']
swordflav = ['slash', 'cut', 'stab']
bowflav = ['pierces', 'punctures', 'penetrates']

monsflav = ['claws', 'bites', 'rakes']

dragonspearflav = ['send twisting shockwaves into', 'brutally jab',
        'viciously stab']
npcflav = ['deeply gashes', 'plunges his sword into', 'viciously thrusts']
bossflav = ['eviscerates', 'tears deeply into', 'plunges his claws into']

# the NetHack solution: text breaks are now more flexible to the player
def textbreak():
    moveon = getpass.getpass(prompt = "--More--")
    if moveon == moveon:
        pass
