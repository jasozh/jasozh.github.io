"""
Code for the combat mechanism
"""

import time
import random

import variables
import death

def combat():
    # monster variables
    monsterhp = 9
    monsdamage = random.randint(1, 5)

    while True:
        clubhit = random.choice(variables.clubflav)
        swordhit = random.choice(variables.swordflav)
        bowhit = random.choice(variables.bowflav)
        dspearhit = random.choice(variables.dragonspearflav)

        monshit = random.choice(variables.monsflav)

        if variables.inventory == 2:
            # sword does the most damage, as usual
            char_damage = random.randint(4, 8)
        elif variables.inventory == 4:
            # ultra weapons deserve to be ultra
            char_damage = random.randint(7, 12)
        else:
            # crossbow and club do the same damage
            char_damage = random.randint(2, 5)

        char_hitchance = random.randint(1, 5)
        mons_hitchance = random.randint(1, 6)

        if char_hitchance == 1:
            if variables.inventory == 3:
                print("Your quarrel misses the %s!" % variables.char_enemy)
                time.sleep(1)
            else:
                print("You miss the %s!" % variables.char_enemy)
                time.sleep(1)

        else:
            if variables.inventory == 1:
                print("You %s the %s, dealing %d damage!"
                        % (clubhit, variables.char_enemy, char_damage))
            elif variables.inventory == 2:
                print("You %s the %s, dealing %d damage!"
                        % (swordhit, variables.char_enemy, char_damage))
            elif variables.inventory == 3:
                print("Your quarrel %s the %s, dealing %d damage!"
                        % (bowhit, variables.char_enemy, char_damage))
            elif variables.inventory == 4:
                print("You %s the %s, dealing %d damage!"
                        % (dspearhit, variables.char_enemy, char_damage))
            monsterhp = monsterhp - char_damage

            if monsterhp < 1:
                variables.textbreak()
                print("You have slain the %s!" % variables.char_enemy)
                variables.survive_num = variables.survive_num + 1
                variables.killcount = variables.killcount + 1
                time.sleep(1)
                break
            else:
                time.sleep(1)

        if mons_hitchance == 1:
            print("The %s misses!" % variables.char_enemy)
            time.sleep(1)
        else:
            print("The %s %s you, dealing %d damage!"
                    % (variables.char_enemy, monshit, monsdamage))
            variables.hp = variables.hp - monsdamage
            time.sleep(1)

        if variables.hp < 1:
            variables.textbreak()
            death.death()
            break
